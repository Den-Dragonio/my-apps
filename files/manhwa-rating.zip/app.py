from flask import Flask, render_template, redirect, url_for, request, flash
from flask_login import LoginManager, UserMixin, login_user, logout_user, current_user, login_required
import sqlite3
import os
from werkzeug.utils import secure_filename
import re  # Для очищення назв файлів від спецсимволів
import webbrowser
from threading import Timer

# --- 1. НАЛАШТУВАННЯ ---
app = Flask(__name__)
app.config['SECRET_KEY'] = 'SecretKey123'  # У продакшені змініть на складний ключ
DATABASE = 'manhwa_db.sqlite'

# Налаштування завантаження файлів
UPLOAD_FOLDER = 'static/covers'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Налаштування Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Будь ласка, увійдіть для доступу.'

# --- 2. РОБОТА З БАЗОЮ ДАНИХ ---

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Ініціалізація структури БД."""
    conn = get_db_connection()
    with conn:
        # Основна таблиця
        conn.execute("""
            CREATE TABLE IF NOT EXISTS Manhwa (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                cover_image TEXT,
                rating REAL,        -- Рейтинг (1.0 - 10.0)
                tags TEXT,          -- Теги через кому
                status TEXT,        -- Ongoing, Completed, Dropped
                manhwa_date TEXT,   -- Дата огляду (встановлює адмін)
                chapters INTEGER,   -- Кількість глав
                is_red_star INTEGER DEFAULT 0 -- 1 якщо червоні зірки
            );
        """)
        
        # Таблиця користувачів
        conn.execute("""
            CREATE TABLE IF NOT EXISTS User (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                is_admin INTEGER DEFAULT 0
            );
        """)
        
        # Створення Адміна (якщо ще немає)
        cursor = conn.execute("SELECT id FROM User WHERE username = 'admin'")
        if cursor.fetchone() is None:
             conn.execute("INSERT INTO User (username, password, is_admin) VALUES (?, ?, ?)",
                         ('admin', 'adminpassword', 1))
             print("Адміністратор створений: admin / adminpassword")
    conn.close()

# Перевірка папки та ініціалізація
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

init_db()

# --- 3. МОДЕЛЬ КОРИСТУВАЧА ТА УТИЛІТИ ---

class User(UserMixin):
    def __init__(self, id, username, is_admin=0):
        self.id = id
        self.username = username
        self.is_admin = is_admin
    
    @staticmethod
    @login_manager.user_loader
    def load_user(user_id):
        conn = get_db_connection()
        user_data = conn.execute("SELECT id, username, is_admin FROM User WHERE id = ?", (user_id,)).fetchone()
        conn.close()
        if user_data:
            return User(user_data['id'], user_data['username'], user_data['is_admin'])
        return None

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# --- 4. МАРШРУТИ (ROUTES) ---

@app.route('/')
def index():
    # Отримуємо параметри
    sort_by = request.args.get('sort', 'rating') # Дефолт: рейтинг
    order = request.args.get('order', 'DESC') 
    selected_statuses = request.args.getlist('status')

    # Валідація (безпека від SQL-ін'єкцій в ORDER BY)
    if sort_by not in ['manhwa_date', 'rating', 'chapters']:
        sort_by = 'rating'
    if order not in ['ASC', 'DESC']:
        order = 'DESC'
        
    conn = get_db_connection()
    
    # 1. Загальна кількість
    total_count = conn.execute("SELECT COUNT(*) FROM Manhwa").fetchone()[0]

    # 2. Побудова основного запиту
    query = "SELECT id, title, description, cover_image, tags, status, manhwa_date, rating, chapters, is_red_star FROM Manhwa"
    params = []

    # Фільтрація WHERE
    if selected_statuses:
        placeholders = ','.join(['?'] * len(selected_statuses))
        query += f" WHERE status IN ({placeholders})"
        params.extend(selected_statuses)
    
    # Сортування ORDER BY
    query += f" ORDER BY {sort_by} {order}"
    
    latest_manhwa = conn.execute(query, params).fetchall()
    
    # 3. Топ рейтинг для сайдбару (обов'язково беремо tags)
    top_rated_manhwa = conn.execute("""
        SELECT id, title, rating, tags, chapters, is_red_star
        FROM Manhwa 
        WHERE rating IS NOT NULL 
        ORDER BY rating DESC 
        LIMIT 5
    """).fetchall()
    
    conn.close()
    
    return render_template('index.html', 
                           latest_manhwa=latest_manhwa, 
                           top_rated_manhwa=top_rated_manhwa,
                           current_sort=sort_by,
                           current_order=order,
                           selected_statuses=selected_statuses,
                           total_count=total_count)

@app.route('/manhwa/<int:manhwa_id>')
def manhwa_details(manhwa_id):
    conn = get_db_connection()
    manhwa = conn.execute('SELECT * FROM Manhwa WHERE id = ?', (manhwa_id,)).fetchone()
    conn.close()
    
    if manhwa is None:
        return "Манхва не знайдена", 404
    
    return render_template('details.html', manhwa=manhwa)

@app.route('/add', methods=['GET', 'POST'])
@login_required
def add_manhwa():
    if not current_user.is_admin:
        return redirect(url_for('index'))

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        tags = request.form['tags']
        status = request.form['status']
        manhwa_date = request.form.get('manhwa_date')
        chapters = request.form.get('chapters', type=int)
        
        # Чекбокс (1 або 0)
        is_red_star = 1 if request.form.get('is_red_star') else 0
        
        cover_filename = None
        rating_val = request.form.get('rating_score', type=float)
        
        # Логіка рейтингу при додаванні
        if status == 'Dropped':
            rating_val = None
        elif rating_val is not None and not (1 <= rating_val <= 10):
            rating_val = None

        # Завантаження фото з очищенням імені
        if 'cover_file' in request.files:
            file = request.files['cover_file']
            if file.filename != '' and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                # Видаляємо заборонені символи Windows
                safe_title = re.sub(r'[\\/*?:"<>|]', "", title).replace(' ', '_')
                cover_filename = f"{safe_title}_{filename}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], cover_filename))

        if not title:
            flash('Назва обов\'язкова!', 'danger')
        else:
            conn = get_db_connection()
            conn.execute("""
                INSERT INTO Manhwa (title, description, tags, status, cover_image, rating, manhwa_date, chapters, is_red_star) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (title, description, tags, status, cover_filename, rating_val, manhwa_date, chapters, is_red_star))
            conn.commit()
            conn.close()
            flash(f'Манхва "{title}" додана!', 'success')
            return redirect(url_for('index'))
            
    return render_template('add.html')

@app.route('/edit/<int:manhwa_id>', methods=['GET', 'POST'])
@login_required
def edit_manhwa(manhwa_id):
    if not current_user.is_admin:
        return redirect(url_for('index'))

    conn = get_db_connection()
    manhwa = conn.execute('SELECT * FROM Manhwa WHERE id = ?', (manhwa_id,)).fetchone()

    if manhwa is None:
        conn.close()
        return "Манхва не знайдена", 404

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        tags = request.form['tags']
        status = request.form['status']
        manhwa_date = request.form.get('manhwa_date')
        chapters = request.form.get('chapters', type=int)
        cover_filename = manhwa['cover_image'] 
        
        is_red_star = 1 if request.form.get('is_red_star') else 0

        # --- ЛОГІКА ОНОВЛЕННЯ РЕЙТИНГУ ---
        rating_val = request.form.get('rating_score', type=float)
        final_rating = None
        
        if status == 'Dropped':
            final_rating = None
        elif rating_val is not None:
            # Якщо прийшло нове значення
            if 1 <= rating_val <= 10:
                final_rating = rating_val
            else:
                final_rating = None
        else:
            # Якщо поле пусте (зірки не чіпали), залишаємо старе
            final_rating = manhwa['rating'] 
        # ---------------------------------

        # Фото
        if 'cover_file' in request.files:
            file = request.files['cover_file']
            if file.filename != '' and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                safe_title = re.sub(r'[\\/*?:"<>|]', "", title).replace(' ', '_')
                cover_filename = f"{safe_title}_{filename}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], cover_filename))

        conn.execute("""
            UPDATE Manhwa 
            SET title = ?, description = ?, tags = ?, status = ?, cover_image = ?, rating = ?, manhwa_date = ?, chapters = ?, is_red_star = ?
            WHERE id = ?
        """, (title, description, tags, status, cover_filename, final_rating, manhwa_date, chapters, is_red_star, manhwa_id))
        conn.commit()
        conn.close()
        
        flash('Зміни збережено!', 'success')
        return redirect(url_for('manhwa_details', manhwa_id=manhwa_id))
            
    conn.close()
    return render_template('add.html', manhwa=manhwa, is_editing=True)

@app.route('/delete/<int:manhwa_id>', methods=['POST'])
@login_required
def delete_manhwa(manhwa_id):
    if not current_user.is_admin: return redirect(url_for('index'))
    conn = get_db_connection()
    manhwa = conn.execute('SELECT * FROM Manhwa WHERE id = ?', (manhwa_id,)).fetchone()
    if manhwa:
        if manhwa['cover_image']:
            try: os.remove(os.path.join(app.config['UPLOAD_FOLDER'], manhwa['cover_image']))
            except: pass
        conn.execute('DELETE FROM Manhwa WHERE id = ?', (manhwa_id,))
        conn.commit()
        flash('Манхва видалена.', 'success')
    conn.close()
    return redirect(url_for('index'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated: return redirect(url_for('index'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        conn = get_db_connection()
        user_data = conn.execute("SELECT id, username, password, is_admin FROM User WHERE username = ?", (username,)).fetchone()
        conn.close()
        if user_data and user_data['password'] == password: 
            user = User(user_data['id'], user_data['username'], user_data['is_admin'])
            login_user(user)
            return redirect(url_for('index'))
        else: flash('Невірні дані.', 'danger')
    return render_template('login.html')

@app.route('/logout')
@login_required 
def logout():
    logout_user()
    return redirect(url_for('index'))

# --- 5. ЗАПУСК ДОДАТКУ ---

def open_browser():
    # Відкриває браузер через 1.5 секунди
    webbrowser.open_new("http://127.0.0.1:5000")

if __name__ == '__main__':
    # Запускаємо таймер відкриття браузера
    Timer(1.5, open_browser).start()
    
    # Вимикаємо debug=True, щоб вікно не відкривалося двічі
    app.run(debug=False)