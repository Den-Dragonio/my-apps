@echo off
TITLE Manhwa Site Launcher
:: Встановлюємо кодування UTF-8, щоб кирилиця відображалася нормально
chcp 65001 >nul

:: Переходимо в папку, де лежить цей файл (важливо, якщо запускати від імені адміна)
cd /d "%~dp0"

echo ===================================================
echo      ЗАПУСК САЙТУ МАНХВ
echo ===================================================
echo.

:: 1. Перевірка наявності Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo [ПОМИЛКА] Python не знайдено!
    echo Будь ласка, встановіть Python з сайту python.org (поставте галочку "Add to PATH")
    echo.
    pause
    exit
)

:: 2. Перевірка наявності папки venv
if exist "venv" (
    echo [INFO] Віртуальне середовище знайдено.
    echo Запуск...
) else (
    color 0E
    echo [УВАГА] Перший запуск. Налаштування може зайняти хвилину...
    echo.
    
    echo 1/2 Створення ізольованого середовища (venv)...
    python -m venv venv
    
    echo 2/2 Завантаження бібліотек...
    venv\Scripts\python -m pip install --upgrade pip
    venv\Scripts\pip install -r requirements.txt
    
    color 0A
    echo.
    echo [ОК] Успішно встановлено!
)

:: 3. Запуск самого сайту
echo.
echo ===================================================
echo      САЙТ ЗАПУЩЕНО!
echo      Не закривайте це вікно, поки користуєтесь сайтом.
echo ===================================================
echo.

:: Запускаємо app.py через Python з папки venv
venv\Scripts\python app.py

pause