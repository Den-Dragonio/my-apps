Connect 4 — 3D (Lua / LÖVE 11.4+) — Linux Package

How to run:
1. Install LÖVE 2D:
   - Ubuntu / Debian: sudo apt install love
   - Fedora:          sudo dnf install love
   - Arch Linux:      sudo pacman -S love
   - Flatpak:         flatpak install flathub org.love2d.love2d
2. Launch the game:
   ./connect4-3d.sh
   (or directly: love Connect4_3D.love)
