#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
if command -v love >/dev/null 2>&1; then
    exec love "$DIR/Connect4_3D.love"
elif command -v flatpak >/dev/null 2>&1 && flatpak info org.love2d.love2d >/dev/null 2>&1; then
    exec flatpak run org.love2d.love2d "$DIR/Connect4_3D.love"
else
    echo "LÖVE 2D (11.4+) is required to run Connect 4 — 3D on Linux."
    echo "Install via: sudo apt install love   (Debian/Ubuntu)"
    echo "          or sudo pacman -S love     (Arch)"
    echo "          or sudo dnf install love   (Fedora)"
    echo "          or flatpak install flathub org.love2d.love2d"
    exit 1
fi
